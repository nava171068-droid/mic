"use strict";
const http = require("http");
const { WebSocketServer } = require("ws");

const PORT = process.env.PORT || 8080;
const MAX_PEERS = 50;
const rooms = new Map();

const httpServer = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
  res.end("Mic Bridge relay OK\n");
});
const wss = new WebSocketServer({ server: httpServer, maxPayload: 64 * 1024 });

function sendJson(c, obj) {
  if (c.ws.readyState === 1) c.ws.send(JSON.stringify(obj));
}

function broadcastRoom(room) {
  const msg = JSON.stringify({
    t: "room",
    host: room.host,
    proximity: room.proximity,
    range: room.range,
    peers: [...room.peers.values()].map((p) => ({ id: p.id, name: p.name, speaking: p.mic })),
  });
  for (const p of room.peers.values()) {
    if (p.ws.readyState === 1) p.ws.send(msg);
  }
}

function freeId(room) {
  for (let i = 1; i <= 255; i++) if (!room.peers.has(i)) return i;
  return 0;
}

function leave(c) {
  const room = c.room;
  if (!room) return;
  room.peers.delete(c.id);
  c.room = null;
  c.mic = false;
  if (room.peers.size === 0) {
    rooms.delete(room.name);
    return;
  }
  if (room.host === c.id) room.host = room.peers.keys().next().value;
  broadcastRoom(room);
}

function distance(a, b) {
  const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

// frame ที่ส่งออก: [id ผู้พูด 1 byte][gain 0-100 1 byte][PCM16 LE 16 kHz mono]
function relayAudio(c, data) {
  const room = c.room;
  if (!room || !c.mic || data.length > 4096) return;
  for (const p of room.peers.values()) {
    if (p === c || p.ws.readyState !== 1) continue;
    if (p.ws.bufferedAmount > 256 * 1024) continue;
    let gain = 100;
    if (room.proximity) {
      if (!c.hasPos || !p.hasPos || c.d !== p.d) continue;
      const d = distance(c, p);
      if (d >= room.range) continue;
      gain = Math.max(1, Math.round(100 * (1 - d / room.range)));
    }
    p.ws.send(Buffer.concat([Buffer.from([c.id, gain]), data]), { binary: true });
  }
}

wss.on("connection", (ws) => {
  const c = { ws, id: 0, name: "", room: null, mic: false, hasPos: false, x: 0, y: 0, z: 0, d: 0, alive: true };
  ws.on("pong", () => { c.alive = true; });

  ws.on("message", (data, isBinary) => {
    if (isBinary) {
      relayAudio(c, data);
      return;
    }
    let m;
    try { m = JSON.parse(data.toString()); } catch { return; }

    switch (m.t) {
      case "join": {
        if (c.room) return;
        const roomName = String(m.room || "").trim().toLowerCase().slice(0, 32);
        const name = String(m.name || "Player").trim().slice(0, 20) || "Player";
        if (!roomName) { sendJson(c, { t: "error", msg: "ต้องใส่รหัสห้อง" }); return; }
        let room = rooms.get(roomName);
        if (!room) {
          room = { name: roomName, peers: new Map(), host: 0, proximity: false, range: 32 };
          rooms.set(roomName, room);
        }
        if (room.peers.size >= MAX_PEERS) { sendJson(c, { t: "error", msg: "ห้องเต็ม" }); return; }
        c.id = freeId(room);
        c.name = name;
        c.room = room;
        room.peers.set(c.id, c);
        if (room.peers.size === 1) room.host = c.id;
        sendJson(c, { t: "welcome", id: c.id });
        broadcastRoom(room);
        break;
      }
      case "pos": {
        if (![m.x, m.y, m.z].every(Number.isFinite)) return;
        c.x = m.x; c.y = m.y; c.z = m.z; c.d = Number(m.d) || 0;
        c.hasPos = true;
        break;
      }
      case "mic": {
        if (!c.room) return;
        const on = !!m.on;
        if (on === c.mic) return;
        c.mic = on;
        broadcastRoom(c.room);
        break;
      }
      case "settings": {
        const room = c.room;
        if (!room || room.host !== c.id) return;
        room.proximity = !!m.proximity;
        const r = Number(m.range);
        if (Number.isFinite(r)) room.range = Math.min(256, Math.max(4, Math.round(r)));
        broadcastRoom(room);
        break;
      }
    }
  });

  ws.on("close", () => leave(c));
  ws.on("error", () => {});
  ws._client = c;
});

// ส่ง ping ทุก 30 วิ กันโฮสต์ตัดการเชื่อมต่อ และตัดคนที่หลุดไปแล้ว
setInterval(() => {
  for (const ws of wss.clients) {
    const c = ws._client;
    if (c && !c.alive) { ws.terminate(); continue; }
    if (c) c.alive = false;
    ws.ping();
  }
}, 30000);

httpServer.listen(PORT, () => console.log(`Mic Bridge relay listening on ${PORT}`));
