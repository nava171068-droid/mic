# Mic Bridge

An Android app that lets Minecraft Bedrock players talk to each other in voice rooms.
Press the mic in-game (hotbar slot 9 / tag `mic`) and everyone in the room can hear you.
The room owner can turn on proximity voice and set the hearing range.

## Components
- `app/`: Android app (Kotlin)
- `server/`: room relay server (Node.js) that forwards audio between phones

## How it works
1. The app opens a WebSocket at `127.0.0.1:19131`. In Minecraft, run `/connect 127.0.0.1:19131`
   (the world must allow commands/cheats).
2. Every 0.5 s the app asks the game whether the player has the `mic` tag (`testfor @s[tag=mic]`)
   and where the player is (`querytarget @s`).
3. When the mic is on, the app streams audio to the room server, which relays it to the others.
4. Proximity ON: the server only sends audio to players within range and lowers the volume with distance.
   Proximity OFF: everyone in the room hears everyone.

## 1) Run the room server
Quick test on the same phone (Termux):
```
pkg install nodejs
cd server
npm install
npm start
```
Then use `ws://127.0.0.1:8080` as the server address in the app. This only works on your own device.

To let other people join, host the `server/` folder somewhere reachable from the internet
(for example a free Render Web Service: Root Directory = `server`, Build Command = `npm install`,
Start Command = `npm start`) and use `wss://your-app.onrender.com`.
Free plans sleep when idle, so the first connection can take about 30 seconds.

## 2) Get the APK
Download `MicBridge.apk` from the **Releases** page of this repository.
(GitHub Actions builds it automatically from `MicBridge_project.zip`.)

## 3) Install the APK

### Why a normal install may be blocked
In some regions (including Thailand, since September 30, 2026) Android blocks apps from
unverified developers. If you see "Can't install app from an unverified developer",
install with ADB instead. This does not need a computer: Termux can do it on the phone itself.

### Install with Termux + Wireless debugging
1. Install **Termux** and run:
   ```
   pkg update
   pkg install android-tools
   termux-setup-storage
   ```
2. Download `MicBridge.apk` and note where it is (for example the Download folder).
3. On the phone: Settings > Developer options > **Wireless debugging** (turn it on, Wi-Fi required).
   Enable Developer options first by tapping the build number 7 times if needed.
4. Open Termux in split-screen or a floating window so the Wireless debugging screen stays visible.
5. Tap **Pair device with pairing code**. You will see a 6-digit code and an `IP:port`. In Termux run
   (use the numbers on your screen, no `<` or `>`):
   ```
   adb pair 192.168.1.105:38117
   ```
   Enter the 6-digit code when asked. Wait for `Successfully paired`.
6. On the main Wireless debugging screen, read the **IP address & Port** (a different port from pairing) and run:
   ```
   adb connect 192.168.1.105:41737
   adb install ~/storage/downloads/MicBridge.apk
   ```
   `Success` means the app is installed.

Notes:
- The pairing code and ports change every time you reopen the pairing dialog.
- If you get "not enough space", free up some storage and try again.
- If an older version signed with a different key is installed, remove it first:
  `adb uninstall com.mic.bridge`

## How to use
1. Open the app, tap **Start service**, and allow microphone access.
2. In Minecraft run `/connect 127.0.0.1:19131`.
3. Enter the server address, your name and a room code (everyone using the same code joins the same room),
   then tap **Join room**.
4. The first person to join is the room owner and can change proximity voice and range.

## Limitations
- Everyone needs an Android phone with the app installed.
- You need permission to run commands in the world (world owner / operator),
  otherwise `/connect` and the commands the app sends will not work.
- Audio is sent uncompressed at 16 kHz, roughly 256 kbps per speaking player.
