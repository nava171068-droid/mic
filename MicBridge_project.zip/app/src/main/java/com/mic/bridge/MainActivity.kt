package com.mic.bridge

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import org.json.JSONArray

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("mic_bridge", MODE_PRIVATE) }

    private lateinit var statusText: TextView
    private lateinit var micText: TextView
    private lateinit var levelBar: ProgressBar
    private lateinit var serviceButton: Button
    private lateinit var urlInput: EditText
    private lateinit var nameInput: EditText
    private lateinit var roomInput: EditText
    private lateinit var roomButton: Button
    private lateinit var roomStatusText: TextView
    private lateinit var peersText: TextView
    private lateinit var proximitySwitch: Switch
    private lateinit var rangeLabel: TextView
    private lateinit var rangeBar: SeekBar

    private var running = false
    private var inRoom = false
    private var isHost = false
    private var updatingUi = false
    private var pendingAction: (() -> Unit)? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val connected = intent.getBooleanExtra(MicService.EXTRA_CONNECTED, false)
            val micOn = intent.getBooleanExtra(MicService.EXTRA_MIC_ON, false)
            val level = intent.getFloatExtra(MicService.EXTRA_LEVEL, 0f)
            statusText.text = if (connected) "Minecraft: เชื่อมต่อแล้ว" else "Minecraft: ยังไม่เชื่อมต่อ"
            micText.text = if (micOn) "ไมค์: เปิด" else "ไมค์: ปิด"
            micText.setTextColor(if (micOn) Color.rgb(30, 160, 60) else Color.GRAY)
            levelBar.progress = (level * 300).toInt().coerceAtMost(100)

            inRoom = intent.getBooleanExtra(MicService.EXTRA_IN_ROOM, false)
            isHost = intent.getBooleanExtra(MicService.EXTRA_IS_HOST, false)
            roomButton.text = if (inRoom) "ออกจากห้อง" else "เข้าห้อง"
            roomStatusText.text = intent.getStringExtra(MicService.EXTRA_ROOM_STATUS).orEmpty()

            val proximity = intent.getBooleanExtra(MicService.EXTRA_PROXIMITY, false)
            val range = intent.getIntExtra(MicService.EXTRA_RANGE, 32)
            updatingUi = true
            proximitySwitch.isChecked = proximity
            rangeBar.progress = (range - 8).coerceIn(0, rangeBar.max)
            rangeLabel.text = "ระยะที่ได้ยิน: $range บล็อก"
            updatingUi = false
            proximitySwitch.isEnabled = isHost
            rangeBar.isEnabled = isHost && proximity

            peersText.text = formatPeers(intent.getStringExtra(MicService.EXTRA_PEERS).orEmpty())
        }
    }

    private fun formatPeers(json: String): String {
        if (!inRoom || json.isEmpty()) return ""
        val arr = JSONArray(json)
        val sb = StringBuilder("คนในห้อง (${arr.length()})\n")
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            sb.append(if (p.optBoolean("speaking")) "● " else "○ ").append(p.optString("name")).append('\n')
        }
        return sb.toString().trimEnd()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun title(t: String) = TextView(this).apply {
            text = t
            textSize = 20f
            setPadding(0, pad, 0, pad / 3)
        }

        fun input(hint: String, saved: String?, type: Int = InputType.TYPE_CLASS_TEXT) =
            EditText(this).apply {
                this.hint = hint
                setText(saved.orEmpty())
                inputType = type
                setSingleLine()
            }

        root.addView(TextView(this).apply {
            text = "Mic Bridge"
            textSize = 26f
            gravity = Gravity.CENTER
        })

        // ---- Minecraft ----
        root.addView(title("1) เชื่อม Minecraft"))
        root.addView(TextView(this).apply {
            text = "กดเริ่มบริการ แล้วในเกมพิมพ์:\n/connect 127.0.0.1:${MicService.PORT}"
            textSize = 15f
        })
        statusText = TextView(this).apply {
            text = "Minecraft: ยังไม่เชื่อมต่อ"
            textSize = 17f
            setPadding(0, pad / 2, 0, 0)
        }
        root.addView(statusText)
        micText = TextView(this).apply {
            text = "ไมค์: ปิด"
            textSize = 20f
            setTextColor(Color.GRAY)
        }
        root.addView(micText)
        levelBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(levelBar)
        serviceButton = Button(this).apply {
            text = "เริ่มบริการ"
            setOnClickListener { if (running) stopBridge() else withPermissions { startBridge() } }
        }
        root.addView(serviceButton)

        // ---- ห้อง ----
        root.addView(title("2) ห้องคุยเสียง"))
        urlInput = input("ที่อยู่เซิร์ฟเวอร์ เช่น wss://xxx.onrender.com", prefs.getString("url", ""),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        nameInput = input("ชื่อของคุณ", prefs.getString("name", ""))
        roomInput = input("รหัสห้อง", prefs.getString("room", ""))
        root.addView(urlInput)
        root.addView(nameInput)
        root.addView(roomInput)
        roomButton = Button(this).apply {
            text = "เข้าห้อง"
            setOnClickListener { onRoomButton() }
        }
        root.addView(roomButton)
        roomStatusText = TextView(this).apply { textSize = 15f }
        root.addView(roomStatusText)

        proximitySwitch = Switch(this).apply {
            text = "เสียงตามระยะ (เจ้าของห้องตั้งค่า)"
            isEnabled = false
            setOnCheckedChangeListener { _, _ -> if (!updatingUi) sendSettings() }
        }
        root.addView(proximitySwitch)
        rangeLabel = TextView(this).apply { text = "ระยะที่ได้ยิน: 32 บล็อก" }
        root.addView(rangeLabel)
        rangeBar = SeekBar(this).apply {
            max = 120 // 8..128 บล็อก
            progress = 24
            isEnabled = false
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) rangeLabel.text = "ระยะที่ได้ยิน: ${p + 8} บล็อก"
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) { if (!updatingUi) sendSettings() }
            })
        }
        root.addView(rangeBar)
        peersText = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad / 2, 0, 0)
        }
        root.addView(peersText)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(MicService.ACTION_STATE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
    }

    override fun onStop() {
        unregisterReceiver(receiver)
        super.onStop()
    }

    private fun sendSettings() {
        startService(Intent(this, MicService::class.java).apply {
            action = MicService.ACTION_SETTINGS
            putExtra(MicService.EXTRA_PROXIMITY_VALUE, proximitySwitch.isChecked)
            putExtra(MicService.EXTRA_RANGE_VALUE, rangeBar.progress + 8)
        })
    }

    private fun onRoomButton() {
        if (inRoom) {
            startService(Intent(this, MicService::class.java).setAction(MicService.ACTION_LEAVE))
            return
        }
        val url = urlInput.text.toString().trim()
        val name = nameInput.text.toString().trim()
        val room = roomInput.text.toString().trim()
        prefs.edit().putString("url", url).putString("name", name).putString("room", room).apply()
        withPermissions {
            running = true
            serviceButton.text = "หยุดบริการ"
            startForegroundService(Intent(this, MicService::class.java).apply {
                action = MicService.ACTION_JOIN
                putExtra(MicService.EXTRA_URL, url)
                putExtra(MicService.EXTRA_ROOM, room)
                putExtra(MicService.EXTRA_NAME, name)
            })
        }
    }

    private fun withPermissions(action: () -> Unit) {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (needed.isEmpty()) {
            action()
        } else {
            pendingAction = action
            requestPermissions(needed.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        val action = pendingAction
        pendingAction = null
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action?.invoke()
        } else {
            statusText.text = "ต้องอนุญาตการใช้ไมค์ก่อน"
        }
    }

    private fun startBridge() {
        startForegroundService(Intent(this, MicService::class.java))
        running = true
        serviceButton.text = "หยุดบริการ"
    }

    private fun stopBridge() {
        startService(Intent(this, MicService::class.java).setAction(MicService.ACTION_STOP))
        running = false
        inRoom = false
        serviceButton.text = "เริ่มบริการ"
    }
}
