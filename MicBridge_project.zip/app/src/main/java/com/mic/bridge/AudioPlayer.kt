package com.mic.bridge

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** เล่นเสียงของผู้เล่นแต่ละคน (1 AudioTrack ต่อ 1 คน) พร้อมปรับความดังตาม gain 0-100 */
class AudioPlayer {
    companion object {
        const val SAMPLE_RATE = 16000
    }

    private val tracks = HashMap<Int, AudioTrack>()

    @Synchronized
    fun play(senderId: Int, gain: Int, pcm: ByteArray) {
        val track = tracks.getOrPut(senderId) { createTrack() }
        val n = pcm.size / 2
        val src = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
        val out = ShortArray(n)
        val g = gain.coerceIn(0, 100) / 100f
        for (i in 0 until n) {
            out[i] = (src.short * g).toInt().coerceIn(-32768, 32767).toShort()
        }
        track.write(out, 0, n, AudioTrack.WRITE_NON_BLOCKING)
    }

    /** เก็บไว้เฉพาะคนที่ยังอยู่ในห้อง */
    @Synchronized
    fun retain(ids: Set<Int>) {
        val it = tracks.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (e.key !in ids) {
                release(e.value)
                it.remove()
            }
        }
    }

    @Synchronized
    fun releaseAll() {
        tracks.values.forEach { release(it) }
        tracks.clear()
    }

    private fun release(t: AudioTrack) {
        try { t.stop() } catch (_: Exception) {}
        t.release()
    }

    private fun createTrack(): AudioTrack {
        val minBuf = AudioTrack.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 4)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        // เติมเงียบ ~60 ms กันเสียงสะดุดตอนเริ่ม
        val silence = ShortArray(SAMPLE_RATE * 60 / 1000)
        track.write(silence, 0, silence.size, AudioTrack.WRITE_NON_BLOCKING)
        track.play()
        return track
    }
}
