package com.mic.bridge

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.util.Collections
import java.util.UUID
import kotlin.math.sqrt

/**
 * 1) เปิด WebSocket server ที่ 127.0.0.1:19131 ให้ Minecraft ต่อด้วย /connect
 *    แล้วถามเกมทุก 500 ms: ผู้เล่นคนนี้ติด tag "mic" ไหม และอยู่ตำแหน่งไหน
 * 2) ต่อเซิร์ฟเวอร์ห้อง ส่งเสียงไมค์ + ตำแหน่ง และเล่นเสียงของคนอื่นในห้อง
 */
class MicService : Service(), RoomClient.Listener {

    companion object {
        const val PORT = 19131
        const val ACTION_STOP = "com.mic.bridge.STOP"
        const val ACTION_JOIN = "com.mic.bridge.JOIN"
        const val ACTION_LEAVE = "com.mic.bridge.LEAVE"
        const val ACTION_SETTINGS = "com.mic.bridge.SETTINGS"
        const val ACTION_STATE = "com.mic.bridge.STATE"

        const val EXTRA_URL = "url"
        const val EXTRA_ROOM = "room"
        const val EXTRA_NAME = "name"

        const val EXTRA_CONNECTED = "connected"
        const val EXTRA_MIC_ON = "mic_on"
        const val EXTRA_LEVEL = "level"
        const val EXTRA_IN_ROOM = "in_room"
        const val EXTRA_ROOM_STATUS = "room_status"
        const val EXTRA_PEERS = "peers"
        const val EXTRA_IS_HOST = "is_host"
        const val EXTRA_PROXIMITY = "proximity"
        const val EXTRA_RANGE = "range"
        const val EXTRA_PROXIMITY_VALUE = "proximity_value"
        const val EXTRA_RANGE_VALUE = "range_value"

        private const val CHANNEL_ID = "mic_bridge"
        private const val NOTIF_ID = 1
        private const val POLL_MS = 500L
        private const val SAMPLE_RATE = 16000
        private const val CHUNK_SAMPLES = 320 // 20 ms
        private const val CMD_MIC = "testfor @s[tag=mic]"
        private const val CMD_POS = "querytarget @s"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var server: WebSocketServer? = null
    @Volatile private var client: WebSocket? = null
    private val pending: MutableMap<String, String> = Collections.synchronizedMap(HashMap())

    private var micOn = false
    private var recorder: AudioRecord? = null
    @Volatile private var recording = false
    private var recordThread: Thread? = null

    // สถานะห้อง
    private var roomClient: RoomClient? = null
    @Volatile private var roomActive = false
    private var myId = 0
    private var hostId = 0
    private var proximity = false
    private var range = 32
    private var peers: List<Peer> = emptyList()
    private var roomStatus = ""
    private val player = AudioPlayer()

    private val pollRunnable = object : Runnable {
        override fun run() {
            client?.let {
                sendCommand(it, CMD_MIC, "mic")
                sendCommand(it, CMD_POS, "pos")
            }
            handler.postDelayed(this, POLL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_JOIN -> {
                createChannel()
                startForeground(NOTIF_ID, buildNotification("กำลังเข้าห้อง"))
                if (server == null) startServer()
                joinRoom(
                    intent?.getStringExtra(EXTRA_URL).orEmpty(),
                    intent?.getStringExtra(EXTRA_ROOM).orEmpty(),
                    intent?.getStringExtra(EXTRA_NAME).orEmpty()
                )
                return START_STICKY
            }
            ACTION_LEAVE -> {
                leaveRoom("ออกจากห้องแล้ว")
                return START_STICKY
            }
            ACTION_SETTINGS -> {
                val p = intent?.getBooleanExtra(EXTRA_PROXIMITY_VALUE, proximity) ?: proximity
                val r = intent?.getIntExtra(EXTRA_RANGE_VALUE, range) ?: range
                roomClient?.sendSettings(p, r)
                return START_STICKY
            }
        }
        createChannel()
        startForeground(NOTIF_ID, buildNotification("รอ Minecraft เชื่อมต่อ"))
        if (server == null) startServer()
        broadcastState(0f)
        return START_STICKY
    }

    // ---------- Minecraft (/connect) ----------

    private fun startServer() {
        val s = object : WebSocketServer(InetSocketAddress("127.0.0.1", PORT)) {
            override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
                client = conn
                handler.post {
                    updateNotification("เชื่อมต่อกับ Minecraft แล้ว")
                    broadcastState(0f)
                    handler.removeCallbacks(pollRunnable)
                    handler.post(pollRunnable)
                }
            }

            override fun onClose(conn: WebSocket, code: Int, reason: String?, remote: Boolean) {
                if (client == conn) client = null
                handler.post {
                    handler.removeCallbacks(pollRunnable)
                    setMic(false)
                    updateNotification("รอ Minecraft เชื่อมต่อ")
                    broadcastState(0f)
                }
            }

            override fun onMessage(conn: WebSocket, message: String) {
                try {
                    val json = JSONObject(message)
                    val header = json.optJSONObject("header") ?: return
                    if (header.optString("messagePurpose") != "commandResponse") return
                    val type = pending.remove(header.optString("requestId")) ?: return
                    val body = json.optJSONObject("body") ?: return
                    when (type) {
                        // testfor สำเร็จ (statusCode 0) = ผู้เล่นคนนี้ติด tag mic
                        "mic" -> handler.post { setMic(body.optInt("statusCode", -1) == 0) }
                        "pos" -> handlePosition(body)
                    }
                } catch (_: Exception) {
                }
            }

            override fun onError(conn: WebSocket?, ex: Exception) {
                handler.post { updateNotification("ข้อผิดพลาด: ${ex.message}") }
            }

            override fun onStart() {
                connectionLostTimeout = 0
            }
        }
        s.isReuseAddr = true
        s.start()
        server = s
    }

    /** body.details เป็นสตริง JSON: [{"dimension":0,"position":{"x":..,"y":..,"z":..},...}] */
    private fun handlePosition(body: JSONObject) {
        val details = body.optString("details")
        if (details.isEmpty()) return
        val arr = JSONArray(details)
        if (arr.length() == 0) return
        val first = arr.getJSONObject(0)
        val pos = first.optJSONObject("position") ?: return
        roomClient?.takeIf { roomActive }?.sendPos(
            pos.optDouble("x"), pos.optDouble("y"), pos.optDouble("z"),
            first.optInt("dimension", 0)
        )
    }

    private fun sendCommand(conn: WebSocket, command: String, type: String) {
        if (!conn.isOpen) return
        if (pending.size > 40) pending.clear()
        val id = UUID.randomUUID().toString()
        pending[id] = type
        val msg = JSONObject().apply {
            put("header", JSONObject().apply {
                put("version", 1)
                put("requestId", id)
                put("messagePurpose", "commandRequest")
                put("messageType", "commandRequest")
            })
            put("body", JSONObject().apply {
                put("version", 1)
                put("commandLine", command)
                put("origin", JSONObject().put("type", "player"))
            })
        }
        try {
            conn.send(msg.toString())
        } catch (_: Exception) {
        }
    }

    // ---------- ห้อง ----------

    private fun joinRoom(url: String, room: String, name: String) {
        leaveRoom("")
        if (url.isBlank() || room.isBlank()) {
            roomStatus = "ต้องใส่ที่อยู่เซิร์ฟเวอร์และรหัสห้อง"
            broadcastState(0f)
            return
        }
        roomStatus = "กำลังเชื่อมต่อเซิร์ฟเวอร์..."
        broadcastState(0f)
        try {
            val rc = RoomClient(url.trim(), room.trim(), name.trim().ifEmpty { "Player" }, this)
            roomClient = rc
            rc.connect()
        } catch (e: Exception) {
            roomClient = null
            roomStatus = "ที่อยู่เซิร์ฟเวอร์ไม่ถูกต้อง"
            broadcastState(0f)
        }
    }

    private fun leaveRoom(status: String) {
        roomClient?.close()
        roomClient = null
        roomActive = false
        myId = 0
        hostId = 0
        peers = emptyList()
        player.releaseAll()
        roomStatus = status
        if (status.isNotEmpty()) broadcastState(0f)
    }

    override fun onJoined() {
        // เชื่อมต่อสำเร็จ รอ welcome
    }

    override fun onWelcome(myId: Int) {
        handler.post {
            this.myId = myId
            roomActive = true
            roomStatus = "อยู่ในห้องแล้ว"
            roomClient?.sendMic(micOn)
            updateNotification("อยู่ในห้องแล้ว")
            broadcastState(0f)
        }
    }

    override fun onRoom(host: Int, proximity: Boolean, range: Int, peers: List<Peer>) {
        handler.post {
            hostId = host
            this.proximity = proximity
            this.range = range
            this.peers = peers
            player.retain(peers.map { it.id }.toSet())
            broadcastState(0f)
        }
    }

    override fun onAudio(senderId: Int, gain: Int, pcm: ByteArray) {
        player.play(senderId, gain, pcm)
    }

    override fun onError(message: String) {
        handler.post {
            roomStatus = "ผิดพลาด: $message"
            broadcastState(0f)
        }
    }

    override fun onClosed(reason: String) {
        handler.post {
            if (roomClient != null) {
                roomClient = null
                roomActive = false
                peers = emptyList()
                player.releaseAll()
                roomStatus = reason
                broadcastState(0f)
            }
        }
    }

    // ---------- ไมค์ ----------

    private fun setMic(on: Boolean) {
        if (on == micOn) return
        micOn = on
        if (on) startRecording() else stopRecording()
        roomClient?.takeIf { roomActive }?.sendMic(on)
        updateNotification(if (on) "ไมค์เปิด" else "ไมค์ปิด")
        broadcastState(0f)
    }

    @SuppressLint("MissingPermission")
    private fun startRecording() {
        if (recording) return
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, CHUNK_SAMPLES * 2 * 4)
            )
        } catch (e: Exception) {
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return
        }
        recorder = rec
        recording = true
        rec.startRecording()
        recordThread = Thread {
            val buf = ShortArray(CHUNK_SAMPLES)
            var lastBroadcast = 0L
            while (recording) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                onAudioChunk(buf, n)
                val now = System.currentTimeMillis()
                if (now - lastBroadcast > 100) {
                    lastBroadcast = now
                    var sum = 0.0
                    for (i in 0 until n) sum += buf[i] * buf[i].toDouble()
                    val rms = sqrt(sum / n) / 32768.0
                    handler.post { broadcastState(rms.toFloat().coerceIn(0f, 1f)) }
                }
            }
        }.also { it.start() }
    }

    private fun stopRecording() {
        recording = false
        recordThread?.join(500)
        recordThread = null
        recorder?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        recorder = null
    }

    /** buf = PCM 16-bit 16 kHz mono ส่งเข้าห้องถ้าอยู่ในห้อง */
    private fun onAudioChunk(buf: ShortArray, length: Int) {
        if (roomActive) roomClient?.sendAudio(buf, length)
    }

    // ---------- แจ้งหน้าจอ / แจ้งเตือน ----------

    private fun broadcastState(level: Float) {
        val peersJson = JSONArray().apply {
            peers.forEach {
                put(JSONObject().put("id", it.id).put("name", it.name).put("speaking", it.speaking))
            }
        }.toString()
        sendBroadcast(Intent(ACTION_STATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_CONNECTED, client != null)
            putExtra(EXTRA_MIC_ON, micOn)
            putExtra(EXTRA_LEVEL, level)
            putExtra(EXTRA_IN_ROOM, roomActive)
            putExtra(EXTRA_ROOM_STATUS, roomStatus)
            putExtra(EXTRA_PEERS, peersJson)
            putExtra(EXTRA_IS_HOST, roomActive && myId != 0 && myId == hostId)
            putExtra(EXTRA_PROXIMITY, proximity)
            putExtra(EXTRA_RANGE, range)
        })
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Mic Bridge", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification =
        Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Mic Bridge")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        handler.removeCallbacks(pollRunnable)
        stopRecording()
        roomClient?.close()
        roomClient = null
        roomActive = false
        player.releaseAll()
        try { server?.stop(200) } catch (_: Exception) {}
        server = null
        client = null
        micOn = false
        broadcastState(0f)
        super.onDestroy()
    }
}
