package com.mic.bridge

import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import org.json.JSONObject
import java.net.URI
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class Peer(val id: Int, val name: String, val speaking: Boolean)

/**
 * ต่อเซิร์ฟเวอร์ห้อง (server/server.js)
 * ส่งขึ้น: JSON (join/pos/mic/settings) + เสียง PCM16 แบบ binary
 * รับลง: JSON (welcome/room/error) + เสียง [id][gain][PCM16]
 */
class RoomClient(
    url: String,
    private val room: String,
    private val name: String,
    private val listener: Listener
) {
    interface Listener {
        fun onJoined()
        fun onWelcome(myId: Int)
        fun onRoom(host: Int, proximity: Boolean, range: Int, peers: List<Peer>)
        fun onAudio(senderId: Int, gain: Int, pcm: ByteArray)
        fun onError(message: String)
        fun onClosed(reason: String)
    }

    private val ws = object : WebSocketClient(URI(url)) {
        override fun onOpen(handshakedata: ServerHandshake?) {
            send(JSONObject().put("t", "join").put("room", room).put("name", name).toString())
            listener.onJoined()
        }

        override fun onMessage(message: String) {
            try {
                val j = JSONObject(message)
                when (j.optString("t")) {
                    "welcome" -> listener.onWelcome(j.optInt("id"))
                    "room" -> {
                        val arr = j.optJSONArray("peers")
                        val peers = ArrayList<Peer>()
                        if (arr != null) {
                            for (i in 0 until arr.length()) {
                                val p = arr.getJSONObject(i)
                                peers.add(Peer(p.optInt("id"), p.optString("name"), p.optBoolean("speaking")))
                            }
                        }
                        listener.onRoom(
                            j.optInt("host"), j.optBoolean("proximity"), j.optInt("range", 32), peers
                        )
                    }
                    "error" -> listener.onError(j.optString("msg"))
                }
            } catch (_: Exception) {
            }
        }

        override fun onMessage(bytes: ByteBuffer) {
            if (bytes.remaining() <= 2) return
            val id = bytes.get().toInt() and 0xFF
            val gain = bytes.get().toInt() and 0xFF
            val pcm = ByteArray(bytes.remaining())
            bytes.get(pcm)
            listener.onAudio(id, gain, pcm)
        }

        override fun onClose(code: Int, reason: String?, remote: Boolean) {
            listener.onClosed(if (reason.isNullOrEmpty()) "หลุดการเชื่อมต่อ" else reason)
        }

        override fun onError(ex: Exception) {
            listener.onError(ex.message ?: "เชื่อมต่อไม่ได้")
        }
    }.also { it.connectionLostTimeout = 30 }

    fun connect() = ws.connect()

    fun close() {
        try { ws.close() } catch (_: Exception) {}
    }

    private fun sendJson(obj: JSONObject) {
        if (ws.isOpen) try { ws.send(obj.toString()) } catch (_: Exception) {}
    }

    fun sendMic(on: Boolean) = sendJson(JSONObject().put("t", "mic").put("on", on))

    fun sendPos(x: Double, y: Double, z: Double, dim: Int) = sendJson(
        JSONObject().put("t", "pos").put("x", x).put("y", y).put("z", z).put("d", dim)
    )

    fun sendSettings(proximity: Boolean, range: Int) = sendJson(
        JSONObject().put("t", "settings").put("proximity", proximity).put("range", range)
    )

    fun sendAudio(buf: ShortArray, length: Int) {
        if (!ws.isOpen) return
        val bb = ByteBuffer.allocate(length * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until length) bb.putShort(buf[i])
        try { ws.send(bb.array()) } catch (_: Exception) {}
    }
}
